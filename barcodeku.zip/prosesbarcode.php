<?php
	include('bar128.php');
	echo '<div style="border:0px double #ababab; padding:5px;margin:5px auto;width:250;">';
	echo bar128(stripslashes($_POST['bar']));
	echo '</div>';
?>