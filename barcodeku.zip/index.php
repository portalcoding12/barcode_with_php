<fieldset>
	<legend>Form input barcode menggunakan php </legend>
		<form action="prosesbarcode.php" method="post">
			<b>Silahkan Masukkan Kode</b><input type="text" name="bar" /> <input type="submit" value="Buat Barcode" />
		</form>
</fieldset>

